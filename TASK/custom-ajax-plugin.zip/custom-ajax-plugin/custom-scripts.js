const yourAjaxUrl = './././wp-admin/admin-ajax.php';

document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('update-templates').addEventListener('click', function(e) {
        e.preventDefault();

        
        const currentDateTime = new Date().toISOString();

        
        const lastTemplate = settings.templates[settings.templates.length - 1];

        
        const data = new FormData();
        data.append('action', 'test_jobcart'); 
        data.append('nonce', settings.nonce); 
        data.append('template', lastTemplate); 
        data.append('datetime', currentDateTime); 

        
        fetch(yourAjaxUrl, {
            method: 'POST',
            body: data,
        })
        .then(response => response.json())
        .then(result => {
            console.log(result.status); 
        })
        .catch(error => {
            console.error('Error:', error);
        });
    });
});
