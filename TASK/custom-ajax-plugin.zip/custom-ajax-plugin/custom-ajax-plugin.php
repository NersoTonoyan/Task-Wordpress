<?php
/*
Plugin Name: Custom AJAX Plugin
Description: Custom AJAX functionality for updating user templates.
*/


function custom_ajax_enqueue_scripts() {
    
    wp_enqueue_script('custom-scripts', plugin_dir_url(__FILE__) . 'custom-scripts.js', array('jquery'), null, true);

  
    $settings = array(
        'nonce' => wp_create_nonce(get_current_user_id()),
        'templates' => array('green', 'yellow')
    );
    wp_localize_script('custom-scripts', 'settings', $settings);
}
add_action('wp_enqueue_scripts', 'custom_ajax_enqueue_scripts');


function test_jobcart() {
    
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], $_POST['action'])) {
        $result = ['status' => false];
        wp_send_json($result);
    }

    
    if (!isset($_POST['template']) || !isset($_POST['datetime'])) {
        $result = ['status' => 'empty'];
        wp_send_json($result);
    }

    $template = sanitize_text_field($_POST['template']);
    $datetime = sanitize_text_field($_POST['datetime']);
  
    $user_id = get_current_user_id();

    
    update_user_meta($user_id, 'templates', $template);

    
    $template_date = get_user_meta($user_id, 'template-date', true);
    if (!$template_date) {
        update_user_meta($user_id, 'template-date', $datetime);
        $status = 'inserted';
    } else {
        update_user_meta($user_id, 'template-date-update', $datetime);
        $status = 'update';
    }

    
    $result = ['status' => $status];
    wp_send_json($result);
}
add_action('wp_ajax_test_jobcart', 'test_jobcart');
add_action('wp_ajax_nopriv_test_jobcart', 'test_jobcart');
