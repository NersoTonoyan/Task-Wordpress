<?php

function insert_listing_categories($categories) {
    foreach ($categories as $category) {
        $category_parts = explode('->', $category);

        $parent_id = 0; 

        foreach ($category_parts as $category_part) {
            $term = term_exists($category_part, 'job_listing_categories', $parent_id); 

            if (!$term) {
                $term_args = array(
                    'parent' => $parent_id,
                    'description' => '',
                    'slug' => sanitize_title($category_part),
                );
                $term_id = wp_insert_term($category_part, 'job_listing_categories', $term_args);
                if (!is_wp_error($term_id)) {
                    $parent_id = $term_id['term_id']; 
                }
            } else {
                $parent_id = $term['term_id']; 
            }
        }
    }
}

$listing_categories = ['главная', 'главная->дочерняя', 'главная->дочерняя2'];
insert_listing_categories($listing_categories);

?>